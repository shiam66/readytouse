<?php

namespace App\Http\Controllers;

use App\Models\Customer;
use Illuminate\Http\Request;

class CustomerController extends Controller
{
    public function index(){
        return view('home.homeContent');
    }

    public function customer(){
        $allCustomer = Customer::all();
        return view('home.customerInfo', ['allCustomer'=>$allCustomer]);
    }

    public function storeCustomer(Request $request){
        $this->validate($request,[
            'customerName'=>'required',
            'customerEmail'=>'required',
        ]);

        $customer = new Customer();
        $customer->customerName = $request->customerName;
        $customer->customerEmail = $request->customerEmail;
        $customer->customerMobile = $request->customerMobile;
        $customer->address = $request->address;
        $customer->status = $request->status;
        $customer->save();

        return redirect('/customerInfo')->with('message','Customer info Save Successfully');
    }

    public function editCustomer($id){
        $customerById = Customer::where('id',$id)->first();
        return view('home.editCustomer', ['customerById'=>$customerById]);
    }

    public function updateCustomer(Request $request){
        $this->validate($request,[
            'customerName'=>'required',
            'customerEmail'=>'required',
        ]);

        $customer = Customer::find($request->customerId);

        $customer->customerName = $request->customerName;
        $customer->customerEmail = $request->customerEmail;
        $customer->customerMobile = $request->customerMobile;
        $customer->address = $request->address;
        $customer->status = $request->status;
        $customer->save();

        return redirect('/customerInfo')->with('updateMessage','Customer info Update Successfully');
    }

    public function deleteCustomer($id){
        $customer = Customer::find($id);
        $customer->delete();
        return redirect('/customerInfo')->with('deleteMessage','Customer info Delete Successfully');
    }
}
