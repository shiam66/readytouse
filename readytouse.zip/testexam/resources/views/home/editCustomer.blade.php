@extends('master')

@section('title') Demo panel. - Dashboard @endsection

@section('mainContent')

    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-2">
        <h1 class="h4 mb-0 text-gray-800">Customer Info</h1>
    </div>

    <!-- Content Row -->
    <div class="row">
        <div class="col-lg-12">
            <div class="card mb-4">
                <div class="card-header py-2">
                    <h6 class="m-0 font-weight-bold text-primary">Edit Customer Info</h6>
                </div>
                <div class="card-body">
                    <form name="editCustomer" action="{{ url('/customerInfo/update') }}" method="post" enctype="multipart/form-data">
                        @csrf
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-sm-4 col-form-label">Customer Name</label>
                                    <div class="col-sm-8">
                                        <input type="text" name="customerName" class="form-control" value="{{ $customerById->customerName }}">
                                        <input type="hidden" name="customerId" value="{{ $customerById->id }}">
                                        <span class="text-danger">{{  $errors->has('customerName') ? $errors->first('customerName'): '' }}</span>
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label class="col-sm-4 col-form-label">Customer Email</label>
                                    <div class="col-sm-8">
                                        <input type="email" name="customerEmail" class="form-control" value="{{ $customerById->customerEmail }}">
                                        <span class="text-danger">{{  $errors->has('customerEmail') ? $errors->first('customerEmail'): '' }}</span>
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label class="col-sm-4 col-form-label">Mobile Number</label>
                                    <div class="col-sm-8">
                                        <input type="text" name="customerMobile" class="form-control" value="{{ $customerById->customerMobile }}">
                                        <span class="text-danger">{{  $errors->has('customerMobile') ? $errors->first('customerMobile'): '' }}</span>
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label class="col-sm-4 col-form-label">Address</label>
                                    <div class="col-sm-8">
                                        <textarea name="address" rows="2" class="form-control">{{ $customerById->address }}</textarea>
                                        <span class="text-danger">{{  $errors->has('address') ? $errors->first('address'): '' }}</span>
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label class="col-sm-4 col-form-label">Status</label>
                                    <div class="col-sm-8">
                                        <select class="form-control" name="status">
                                            <option value="1">Active</option>
                                            <option value="0">Inactive</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">

                            </div>
                        </div>
                        <center>
                            <button type="submit" class="btn btn-primary">Update Info</button>
                        </center>
                    </form>
                </div>
            </div>
        </div>
    </div>

@endsection

@section('script')
    <script>
        document.forms['editCustomer'].elements['status'].value={{ $customerById->status }}
    </script>
@endsection
