@extends('master')

@section('title') Demo panel. - Dashboard @endsection

@section('mainContent')

    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-2">
        <h1 class="h4 mb-0 text-gray-800">Customer Info</h1>
    </div>

    <!-- Content Row -->
    <div class="row">
        <div class="col-lg-12">
            <div class="card mb-4">
                <div class="card-header py-2">
                    <h6 class="m-0 font-weight-bold text-primary">Add Customer Info</h6>
                </div>
                <div class="card-body">
                    <form name="frmcontent" action="{{ url('/customerInfo/create') }}" method="post" enctype="multipart/form-data">
                        @csrf
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group row">
                                        <label class="col-sm-4 col-form-label">Customer Name</label>
                                        <div class="col-sm-8">
                                            <input type="text" name="customerName" class="form-control">
                                            <span class="text-danger">{{  $errors->has('customerName') ? $errors->first('customerName'): '' }}</span>
                                        </div>
                                    </div>

                                    <div class="form-group row">
                                        <label class="col-sm-4 col-form-label">Customer Email</label>
                                        <div class="col-sm-8">
                                            <input type="email" name="customerEmail" class="form-control">
                                            <span class="text-danger">{{  $errors->has('customerEmail') ? $errors->first('customerEmail'): '' }}</span>
                                        </div>
                                    </div>

                                    <div class="form-group row">
                                        <label class="col-sm-4 col-form-label">Mobile Number</label>
                                        <div class="col-sm-8">
                                            <input type="text" name="customerMobile" class="form-control">
                                            <span class="text-danger">{{  $errors->has('customerMobile') ? $errors->first('customerMobile'): '' }}</span>
                                        </div>
                                    </div>

                                    <div class="form-group row">
                                        <label class="col-sm-4 col-form-label">Address</label>
                                        <div class="col-sm-8">
                                            <textarea name="address" rows="2" class="form-control"></textarea>
                                            <span class="text-danger">{{  $errors->has('address') ? $errors->first('address'): '' }}</span>
                                        </div>
                                    </div>

                                    <div class="form-group row">
                                        <label class="col-sm-4 col-form-label">Status</label>
                                        <div class="col-sm-8">
                                            <select class="form-control" name="status">
                                                <option value="1">Active</option>
                                                <option value="0">Inactive</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">

                                </div>
                            </div>
                            <center>
                                <button type="submit" class="btn btn-primary">Add New Info</button>
                            </center>
                    </form>
                </div>
            </div>
        </div>

        <div class="col-lg-12">
            <div class="card mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Manage Customer</h6>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                            <thead>
                            <tr>
                                <th>SL No.</th>
                                <th>Customer Name</th>
                                <th>Email</th>
                                <th>Mobile</th>
                                <th>Address</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                            </thead>
                            <tfoot>
                            <tr>
                                <th>SL No.</th>
                                <th>Customer Name</th>
                                <th>Email</th>
                                <th>Mobile</th>
                                <th>Address</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                            </tfoot>
                            <tbody>
                            @foreach($allCustomer as $item)
                                <tr>
                                    <td>{{ $loop->iteration }}</td>
                                    <td>{{ $item->customerName }}</td>
                                    <td>{{ $item->customerEmail }}</td>
                                    <td>{{ $item->customerMobile }}</td>
                                    <td>{{ $item->address }}</td>
                                    <td>
                                        @if($item->status==1)
                                            <span class="badge badge-success">Active</span>
                                        @else
                                            <span class="badge badge-danger">Inactive</span>
                                        @endif
                                    </td>
                                    <td>
                                        <a href="{{ url('/customerInfo/edit/'.$item->id) }}" class="btn btn-primary btn-sm">Edit</a>
                                        <a href="{{ url('/customerInfo/delete/'.$item->id) }}" class="btn btn-danger btn-sm">Delete</a>
                                    </td>
                                </tr>
                            @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

@endsection
