<?php $__env->startSection('title'); ?> Demo panel. - Dashboard <?php $__env->stopSection(); ?>

<?php $__env->startSection('mainContent'); ?>

    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-2">
        <h1 class="h4 mb-0 text-gray-800">Customer Info</h1>
    </div>

    <!-- Content Row -->
    <div class="row">
        <div class="col-lg-12">
            <div class="card mb-4">
                <div class="card-header py-2">
                    <h6 class="m-0 font-weight-bold text-primary">Edit Customer Info</h6>
                </div>
                <div class="card-body">
                    <form name="editCustomer" action="<?php echo e(url('/customerInfo/update')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-sm-4 col-form-label">Customer Name</label>
                                    <div class="col-sm-8">
                                        <input type="text" name="customerName" class="form-control" value="<?php echo e($customerById->customerName); ?>">
                                        <input type="hidden" name="customerId" value="<?php echo e($customerById->id); ?>">
                                        <span class="text-danger"><?php echo e($errors->has('customerName') ? $errors->first('customerName'): ''); ?></span>
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label class="col-sm-4 col-form-label">Customer Email</label>
                                    <div class="col-sm-8">
                                        <input type="email" name="customerEmail" class="form-control" value="<?php echo e($customerById->customerEmail); ?>">
                                        <span class="text-danger"><?php echo e($errors->has('customerEmail') ? $errors->first('customerEmail'): ''); ?></span>
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label class="col-sm-4 col-form-label">Mobile Number</label>
                                    <div class="col-sm-8">
                                        <input type="text" name="customerMobile" class="form-control" value="<?php echo e($customerById->customerMobile); ?>">
                                        <span class="text-danger"><?php echo e($errors->has('customerMobile') ? $errors->first('customerMobile'): ''); ?></span>
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label class="col-sm-4 col-form-label">Address</label>
                                    <div class="col-sm-8">
                                        <textarea name="address" rows="2" class="form-control"><?php echo e($customerById->address); ?></textarea>
                                        <span class="text-danger"><?php echo e($errors->has('address') ? $errors->first('address'): ''); ?></span>
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label class="col-sm-4 col-form-label">Status</label>
                                    <div class="col-sm-8">
                                        <select class="form-control" name="status">
                                            <option value="1">Active</option>
                                            <option value="0">Inactive</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">

                            </div>
                        </div>
                        <center>
                            <button type="submit" class="btn btn-primary">Update Info</button>
                        </center>
                    </form>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        document.forms['editCustomer'].elements['status'].value=<?php echo e($customerById->status); ?>

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\testexam\resources\views/home/editCustomer.blade.php ENDPATH**/ ?>