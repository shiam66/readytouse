<?php $__env->startSection('title'); ?> Marketvine Ltd. - Dashboard <?php $__env->stopSection(); ?>

<?php $__env->startSection('mainContent'); ?>

    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-2">
        <h1 class="h4 mb-0 text-gray-800">Dashboard</h1>
    </div>

    <!-- Content Row -->
    <div class="row">

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\testexam\resources\views/home/homeContent.blade.php ENDPATH**/ ?>