<?php $__env->startSection('title'); ?> Demo panel. - Dashboard <?php $__env->stopSection(); ?>

<?php $__env->startSection('mainContent'); ?>

    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-2">
        <h1 class="h4 mb-0 text-gray-800">Customer Info</h1>
    </div>

    <!-- Content Row -->
    <div class="row">
        <div class="col-lg-12">
            <div class="card mb-4">
                <div class="card-header py-2">
                    <h6 class="m-0 font-weight-bold text-primary">Add Customer Info</h6>
                </div>
                <div class="card-body">
                    <form name="frmcontent" action="<?php echo e(url('/customerInfo/create')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group row">
                                        <label class="col-sm-4 col-form-label">Customer Name</label>
                                        <div class="col-sm-8">
                                            <input type="text" name="customerName" class="form-control">
                                            <span class="text-danger"><?php echo e($errors->has('customerName') ? $errors->first('customerName'): ''); ?></span>
                                        </div>
                                    </div>

                                    <div class="form-group row">
                                        <label class="col-sm-4 col-form-label">Customer Email</label>
                                        <div class="col-sm-8">
                                            <input type="email" name="customerEmail" class="form-control">
                                            <span class="text-danger"><?php echo e($errors->has('customerEmail') ? $errors->first('customerEmail'): ''); ?></span>
                                        </div>
                                    </div>

                                    <div class="form-group row">
                                        <label class="col-sm-4 col-form-label">Mobile Number</label>
                                        <div class="col-sm-8">
                                            <input type="text" name="customerMobile" class="form-control">
                                            <span class="text-danger"><?php echo e($errors->has('customerMobile') ? $errors->first('customerMobile'): ''); ?></span>
                                        </div>
                                    </div>

                                    <div class="form-group row">
                                        <label class="col-sm-4 col-form-label">Address</label>
                                        <div class="col-sm-8">
                                            <textarea name="address" rows="2" class="form-control"></textarea>
                                            <span class="text-danger"><?php echo e($errors->has('address') ? $errors->first('address'): ''); ?></span>
                                        </div>
                                    </div>

                                    <div class="form-group row">
                                        <label class="col-sm-4 col-form-label">Status</label>
                                        <div class="col-sm-8">
                                            <select class="form-control" name="status">
                                                <option value="1">Active</option>
                                                <option value="0">Inactive</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">

                                </div>
                            </div>
                            <center>
                                <button type="submit" class="btn btn-primary">Add New Info</button>
                            </center>
                    </form>
                </div>
            </div>
        </div>

        <div class="col-lg-12">
            <div class="card mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Manage Customer</h6>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                            <thead>
                            <tr>
                                <th>SL No.</th>
                                <th>Customer Name</th>
                                <th>Email</th>
                                <th>Mobile</th>
                                <th>Address</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                            </thead>
                            <tfoot>
                            <tr>
                                <th>SL No.</th>
                                <th>Customer Name</th>
                                <th>Email</th>
                                <th>Mobile</th>
                                <th>Address</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                            </tfoot>
                            <tbody>
                            <?php $__currentLoopData = $allCustomer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($item->customerName); ?></td>
                                    <td><?php echo e($item->customerEmail); ?></td>
                                    <td><?php echo e($item->customerMobile); ?></td>
                                    <td><?php echo e($item->address); ?></td>
                                    <td>
                                        <?php if($item->status==1): ?>
                                            <span class="badge badge-success">Active</span>
                                        <?php else: ?>
                                            <span class="badge badge-danger">Inactive</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <a href="<?php echo e(url('/customerInfo/edit/'.$item->id)); ?>" class="btn btn-primary btn-sm">Edit</a>
                                        <a href="<?php echo e(url('/customerInfo/delete/'.$item->id)); ?>" class="btn btn-danger btn-sm">Delete</a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\testexam\resources\views/home/customerInfo.blade.php ENDPATH**/ ?>